from base64 import b64decode, b64encode
import hashlib
import os
import time
import json


def __jwt_encode_str(x):
    return b64encode(x.encode()).decode().replace("=",'')


def __jwt_encode_dict(x):
    return __jwt_encode_str(json.dumps( x , separators=(',', ':')))
    # return b64encode(
    #     json.dumps( x , separators=(',', ':')).encode()
    #     ).decode().replace("=",'')

def __jwt_decode_dict(x):
    assert type(x) == str, "Input must be string"
    # pad = len(x) % 3
    raw = x + "="*3
    ret = json.loads(b64decode(raw.encode()).decode())
    return ret


def __jwt_make_sig(jwt_head, jwt_data, salt):
    return hashlib.sha256((
        jwt_head + '.' + jwt_data + salt
        ).encode()).hexdigest()


def token_generate(uid):
    salt = os.environ['salt1']
    time_limit = 7 * 24 * 60 * 60 # 7 consecutive days of inactivity
    expiration = int(time.time() + time_limit)
    
    jwt_head = __jwt_encode_dict({
        'alg': 'RSA256',
        'typ': 'JWT'
    })
    
    jwt_data = __jwt_encode_dict({
        'uid': uid,
        'exp': expiration
    })
    
    jwt_sig = __jwt_make_sig(jwt_head, jwt_data, salt)
    
    jwt_full = "%s.%s.%s"%(jwt_head, jwt_data, jwt_sig)
    return jwt_full


def token_read(token):
    salt = os.environ['salt1']
    assert token.count('.') == 2, "JWT invalid"
    
    raw_jwt_head, raw_jwt_data, raw_jwt_sig = token.split('.')
    calc_sig = __jwt_make_sig(raw_jwt_head, raw_jwt_data, salt)
    
    if calc_sig != raw_jwt_sig:
        return {'status': False}
    else:
        jwt_data = __jwt_decode_dict(raw_jwt_data)
        # jwt_head = __jwt_decode_dict(raw_jwt_head)
        expiration = jwt_data['exp']
        curTime = int(time.time())
        if curTime > expiration:
            return {'status': False}
        else:
            print(jwt_data)
            uid = jwt_data['uid']
            exp = jwt_data['exp']
            return {
                'status': True,
                'uid': uid,
                'exp': exp
                }
    
    
def token_getUID(token):
    # check in database / verify structure...
    token_data = token_read(token)
    if not token_data:
        return False
    else:
        return token_data['uid']