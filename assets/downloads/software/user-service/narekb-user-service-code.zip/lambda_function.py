import json
from jwt_tools import *
from cred_tools import *



def auth_isValid(authType, auth):
    if authType == "token":
        return token_read(auth)
    elif authType == "cred":
        return cred_getUID(auth)
    else:
        return {'status': False}
    
def lambda_handler(event, context):
    valid = {'status': False}
    task = None
    

    if ('token' in event['headers']):
        valid = auth_isValid('token', event['headers']['token'])
    elif ('authorization' in event['headers']):
        valid = auth_isValid('cred', event['headers']['authorization'])
    elif ('create_new' in event['headers']):
        valid = cred_create(event['headers']['create_new'])
    elif os.environ['email_verification_route'] in event['requestContext']['http']['path']:
        verify_token = event['requestContext']['http']['path'].split('/')[-1]
        if check_verification_link(verify_token):
            return {
                "statusCode": 200,
                'body': {
                    "status":True,
                    'description': 'Email has been succesfully verified.'
                }
            }
        else:
            return {
                "statusCode": 400,
                'body': {
                    "status":False,
                    'description': 'Email verification failed.'
                }
            }
        
    if 'task' in event['headers']:
        task = event['headers']['task']

    if valid['status']:
        if task == 'verify_email':
            uid = valid['uid']
            if send_verification_email(uid):
                return {
                "statusCode": 200,
                'body': {"status":True,'description':'Verification email sent.'}
                }
            else:
                return {
                "statusCode": 400,
                'body': {"status":False,'description':'Verification email failed to send.'}
                }
        else:
            token = token_generate(valid['uid'])
            if 'change_request' in event['headers']:
                change_request(valid['uid'], event['headers']['change_request'])
            return {
                "statusCode": 200,
                'body': {"token":token,'uid':valid['uid']}
            }
    elif task == 'verify_email':
        return {
            "statusCode": 200,
            'body': {'uid':valid['uid'], 'description': 'Verification email sent.'}
        }
    else:
        description = "Authorization Failed"
        if 'description' in valid:
            description = valid['description']
        return {
            "statusCode": 401,
            'body': description
        }