words = [] # Enter list of profane terms here. Removed my own list for modesty


def has_profanity(x):
    # replacements = {
    #     '-':'',
    #     '_':'',
    #     '.':'',
    #     '':'',
    #     ';':'',
    #     ':':'',
    #     '=':'',
    #     '+':'',
    #     ')':'',
    #     '(':'',
    #     '*':'',
    #     '^':'',
    #     '#':'',
    #     '@':'',
    #     '!':'',
    #     '`':'',
    #     '-':'',
    # }
    test = x.lower().strip()
    if test in words:
        return True
    elif any(x in words for x in test.split()):
        return True
    elif any(x in words for x in test.split('-')):
        return True
    elif any(x in words for x in test.split('_')):
        return True
    elif any(x in words for x in test.split('~')):
        return True
    else:
        return False
