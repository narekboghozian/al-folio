from base64 import b64decode, b64encode
import boto3
import hashlib
import os

def __find_user(user):
    go_user_table_name =  os.environ['go_user_table_name']
    client  = boto3.resource(
        'dynamodb',
        region_name='us-west-2'
        )
    table = client.Table(go_user_table_name)
    response = table.scan()
    uid = False
    for item in response['Items']:
        if item['username'] == user or \
            item['email'] == user:
            uid = item['uid']
            break
    return uid


def __make_salt(seed, length):
    assert type(seed) == str, 'Wrong seed format, must be string'
    return hashlib.sha256(seed.encode()).hexdigest()[:length]
    

def __sha_256_salted(x, salt, iterations):
    fresh = hashlib.sha256((x + '.' + salt).encode()).digest()
    for i in range(iterations):
        fresh = hashlib.sha256(fresh).digest()
    iterated = hashlib.sha256(fresh).hexdigest()
    return iterated


def __get_user_info(uid):
    go_user_table_name =  os.environ['go_user_table_name']
    client  = boto3.resource('dynamodb', region_name='us-west-2')
    table = client.Table(go_user_table_name)
    response = table.get_item(Key={
        'uid': uid
    })
    
    if len(response['Item']) == 0:
        return False
    else:
        return response['Item']


def __verify_user(uid, passwd):
    go_user_table_name =  os.environ['go_user_table_name']
    client  = boto3.resource(
        'dynamodb',
        region_name='us-west-2'
        )
    table = client.Table(go_user_table_name)
    
    response = table.get_item(Key={
        'uid': uid
    })
    
    
    if len(response['Item']) == 0:
        return False
    else:
        salt = response['auth']['salt']
        iterations = response['auth']['iterations']
        passwd_hashed = __sha_256_salted(passwd, salt, iterations)
        stored_passwd = response['Item']['pass']
        if passwd_hashed == stored_passwd:
            # now = int(time.time())
            # table.update_item(
            #     Key = {'uid': uid},
            #     AttributeUpdates={
            #         'last_online': now
            #     })
            return True
        else:
            return False


def __input_validation(input_type, value):
    allowed_characters = '1234567890qwertyuiopasdfghjklzxcvbnm-_~'
    if input_type == 'username':
        username = value
        from profanity_check import has_profanity
        if len(username) > 16 or len(username) < 6:
            return False
        elif has_profanity(username):
            return False
        elif not all(ch in allowed_characters for ch in username):
            return False
        else:
            return True
        
    elif input_type == 'email':
        return True #must edit #########################################
    elif input_type == 'passwd':
        return True #must edit #########################################


def __add_user(username, email, passwd):
    import time
    import random
    
    go_user_table_name =  os.environ['go_user_table_name']
    client  = boto3.resource('dynamodb')
    table   = client.Table(go_user_table_name)
    
    response = table.scan()
    num_users = len(response['Items'])
    # uid_hash = hashlib.sha256(str(time.time()+random.randint(0,2**16)).encode())[0:16]
    uid_hash = __make_salt(str(time.time()+random.randint(0,2**16)), 10)
    
    uid = 'u_%s'%(uid_hash)
    # uid = uid_hash
    
    salt = __make_salt(uid, 16)
    iterations = 10000
    passwd_hashed = __sha_256_salted(passwd, salt, iterations)
    
    
    now = int(time.time())
    
    data = {
        "uid": uid,
        "username": username,
        "user_number": num_users,
        "auth": {
            "passwd": passwd_hashed,
            "salt": salt,
            "iterations": iterations
            },
        "email": email,
        "email_verified": False,
        "creation": now
    }
    acct = table.put_item(Item= data)
    if acct['ResponseMetadata']['HTTPStatusCode'] == 200:
        return uid
    else:
        return False
    


def cred_getUID(auth):
    user, passwd = b64decode(
        auth.split()[-1]
        ).decode().split(':')
    uid = __find_user('testUser1') 
    if uid and __verify_user(uid, passwd):
        return {'uid': uid}
    else:
        return {'status': False}



def cred_create(request):
    username = request['username']
    email = request['email']
    passwd = request['passwd']
    if __find_user(username):
        return {
            'status': False, 
            'status_detail': 'username_unavailable', 
            'description':'That username is not available.'}
    elif not __input_validation('username', username):
        return {
            'status': False, 
            'status_detail': 'username_unavailable', 
            'description':'That username is not available.'}
    elif not __input_validation('passwd', passwd):
        return {
            'status': False, 
            'status_detail': 'password_invalid', 
            'description':'That password is not valid.'}
    elif __find_user(email):
        return {
            'status': False, 
            'status_detail': 'password_invalid', 
            'description':'That password is not valid.'}
    else:
        uid = __add_user(username, email, passwd)
        if not uid:
            return {'status': False}
        else:
            return {
                'status': True, 
                'status_detail': 'account_created', 
                'description':'Account created successfully.',
                'uid': uid,
                'username': username,
                'email': email
            }


def change_request(uid, request):
    attr = request['attribute']
    valid_attrs = {
        'email',
        'passwd'
    }
    go_user_table_name =  os.environ['go_user_table_name']
    client  = boto3.resource('dynamodb')
    table   = client.Table(go_user_table_name)
    if attr == 'email':
        table.update_item(
            Key = {'uid': uid},
            UpdateExpression="SET email= :email",
            ExpressionAttributeValues={
            ':email': request['new_email']})
    elif attr == 'passwd':
        response = table.get_item(Key={
            'uid': uid
        })
        salt = response['auth']['salt']
        iterations = response['auth']['iterations']
        passwd_hashed = __sha_256_salted(passwd, salt, iterations)
        table.update_item(
            Key = {'uid': uid},
            UpdateExpression="SET passwd= :passwd",
            ExpressionAttributeValues={
            ':passwd': passwd_hashed})
    else:
        return False
    

def __send_email(src_addr, dest_addr, subj, mesg):
    client = boto3.client('ses', region_name='us-west-1')
    response = client.send_email(
        Source=src_addr,
        Destination={
            'ToAddresses': [
                dest_addr,
            ]
        },
        Message={
            'Subject': {
                'Data': subj
            },
            'Body': {
                'Text': {
                    'Data': mesg
                }
            }
        }
    )
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        return True
    else:
        return False


def __make_verification_link(uid):
    base_link = os.environ['email_verification_url']
    verification_route = os.environ['email_verification_route']
    user_info = __get_user_info(uid)
    if not user_info:
        return False
    else: 
        import json
        import time
        from base64 import b64decode, b64encode
        salt = user_info['auth']['salt']
        time_limit = 14 * 24 * 60 * 60
        expiration = int(time.time() + time_limit)
        body = {
            'email': user_info['email'],
            'exp': expiration,
            'uid': uid
        }
        encoded_body = b64encode(
            json.dumps(body, separators=(',', ':')).encode()
            ).decode().replace("=",'')
            
        sig = hashlib.sha256((encoded_body + '.' + salt).encode()).hexdigest()
        
        verif_token = encoded_body + '.' + sig
        full_link = os.path.join(base_link, verification_route, verif_token)
        return full_link


def __set_email_verification_status(uid, status):
    go_user_table_name =  os.environ['go_user_table_name']
    client  = boto3.resource(
        'dynamodb',
        region_name='us-west-2'
        )
    table = client.Table(go_user_table_name)
    response = table.get_item(Key={
        'uid': uid
    })
    print(response)
    if len(response['Item']) == 0:
        return False
    else:
        table.update_item(
            Key = {'uid': uid},
            UpdateExpression="SET email_verified= :status",
            ExpressionAttributeValues={
            ':status': status})
        return True



def check_verification_link(verif_token):
    import json
    import time
    encoded_body, raw_sig = verif_token.split('.')
    encoded_body
    body = json.loads(b64decode((encoded_body+'===').encode()).decode())
    uid = body['uid']
    exp = body['exp']
    email = body['email']
    user_info = __get_user_info(uid)
    now = int(time.time())
    print(verif_token)
    print(user_info)
    print(body)
    print(now)
    if user_info != False \
        and user_info['uid'] == uid \
        and user_info['email'] == email \
        and now < exp:
        salt = user_info['auth']['salt']
        sig = hashlib.sha256((encoded_body + '.' + salt).encode()).hexdigest()
        print(sig)
        print(raw_sig)
        print(encoded_body)
        if sig == raw_sig:
            return __set_email_verification_status(uid, True)
        else:
            return False
    else:
        return False


def send_verification_email(uid):
    user_info = __get_user_info(uid)
    if not user_info:
        return False
    else: 
        verify_link = __make_verification_link(uid)
        if not verify_link:
            return False
        else:
            addr = user_info['email']
            src = 'noreply@narekb.com'
            dest = 'test-user@narekb.com'
            subj = "Email Verification - go.narekb.com" 
            mesg = "Click the following link within 14 days to verify your email for go.narekb.com\n\n\n%s"%(verify_link)
            if __send_email(src, dest, subj, mesg):
                return True
            else:
                return False
            
        
    