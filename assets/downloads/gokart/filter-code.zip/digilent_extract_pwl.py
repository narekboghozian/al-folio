import pandas as pd
import numpy as np
import json, os, sys

def get_args():
	if len(sys.argv) > 2:
		print('You have specified too many arguments')
		sys.exit()
	if len(sys.argv) < 2:
		print('You need to specify the extracted waveform csv file to be used')
		print('Ex: python3 %s path/to/waveform.csv'%(os.path.basename(__file__)))
		sys.exit()
	filename = str(sys.argv[1])
	if not os.path.exists(filename):
		print('The file specified does not exist')
		sys.exit()
	ext = filename.split('.')[-1]
	if ext != 'csv':
		print('Filetype must be csv')
		sys.exit()
	return filename

def main():
	realpath = get_args()
	content = pd.read_csv(realpath, comment='#')
	choice = 0
	if len(content.columns) == 3:
		while not ((choice == '1') or (choice == '2')):
			choice = input("Which channel (1 or 2)\n>> ")
			if not ((choice == '1') or (choice == '2')):
				print("Enter 1 or 2")
	elif len(content.columns) == 2:
		choice = 1
	else:
		print("This script was not built to handle more than 2 channels output.. fix it..")
	choice = int(choice)
	new_filename = os.path.splitext(realpath)[0] + '_channel-%d_pwl.csv'%(choice)
	print("Saving to %s"%(new_filename))
	content.iloc[:, 0] = content.iloc[:, 0] - content.iloc[0, 0]
	col_0 = content.columns[0]
	col_n = content.columns[choice]
	content[[col_0, col_n]].to_csv(new_filename, index=False, header=False)

main()
